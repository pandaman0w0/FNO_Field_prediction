#Project Title#
Simulating Optical Resonant Modes Using Physics informed deep
learning models

This work uses a Fourier Neural Operator  to predict the field intensity of a dielectric particle inside a micro F-P cavity. 

Description of code files: 
1. FNO_working.ipynb is for training the model, and performing curriculum learning. 

This code is modified from FNO available here: https://github.com/AI-Complexity-Lab/cse598/tree/main/hw1

2. The file test of FNO performs data visualization and model saving. The model size/ layers etc. need to match between the two files. The last section need to load experimental data and perform data linear interpolation. 